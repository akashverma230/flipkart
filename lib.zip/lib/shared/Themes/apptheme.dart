import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeProvider extends ChangeNotifier {
  ThemeProvider() {
    theme();
  }

  bool _theme = false;

  get getTheme => _theme;

  void setTheme() async {
    _theme = !_theme;
    notifyListeners();
    await SharedPreferences.getInstance()
        .then((value) => value.setBool("isItDark", _theme))
        .catchError((onError) {
      print("fetch failed");
    });
  }

  void theme() async {
    final persistData = SharedPreferences.getInstance();
    final data = await persistData;
    _theme = data.getBool("isItDark") ?? false;
    notifyListeners();
  }
}

class Themes {
  static ThemeData light() {
    return ThemeData(
      scaffoldBackgroundColor: Colors.white,
      cardColor: Colors.white,
      accentColor: Colors.black,
      indicatorColor: Colors.grey,
    );
  }

  static ThemeData dark() {
    return ThemeData(
        scaffoldBackgroundColor: Colors.black87,
        cardColor: Colors.black,
        accentColor: Colors.white,
        indicatorColor: Colors.grey);
  }
}

import 'package:flipkart/shared/cards/usercard.dart';
import 'package:flutter/material.dart';

Widget Userlist(String s,BuildContext context){
  return  Container(
    padding: EdgeInsets.all(5),
    child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Divider(thickness: 2,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
  s,
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20,color: Theme.of(context).accentColor),
              ),
              //SizedBox(width: MediaQuery.of(context).size.width*0.20,),
              ElevatedButton(onPressed: (){}, child: Text('View All'))
            ],
          ),
          SizedBox(
            height: 20,
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                UserCard(
                    MediaQuery.of(context).size.height * 0.25,
                    MediaQuery.of(context).size.width * 0.40,
                    Column(
                      children: [
                        Expanded(
                          flex: 2,
                          child: Image.asset('assets/tws.jpg')),
                        SizedBox(
                          width: 5,
                        ),
                        Text(
                          'True Wireless',
                          style: TextStyle(fontWeight: FontWeight.bold,color: Theme.of(context).accentColor),
                        )
                      ],
                    ),context),
                UserCard(
                    MediaQuery.of(context).size.height * 0.25,
                    MediaQuery.of(context).size.width * 0.40,
                    Column(
                      children: [
                        Expanded(
                          flex: 2,
                          child: Image.asset('assets/smw.png')),
                        SizedBox(
                          width: 5,
                        ),
                        Text(
                          'Smart Watches',
                          style: TextStyle(fontWeight: FontWeight.bold,color: Theme.of(context).accentColor),
                        )
                      ],
                    ),context),
                UserCard(
                    MediaQuery.of(context).size.height * 0.25,
                    MediaQuery.of(context).size.width * 0.40,
                    Column(
                      children: [
                        Expanded(
                          flex: 2,
                          child: Image.asset('assets/atomic.png')),
                        SizedBox(
                          width: 5,
                        ),
                        Text(
                          'Books',
                          style: TextStyle(fontWeight: FontWeight.bold,color: Theme.of(context).accentColor),
                        )
                      ],
                    ),context),
                UserCard(
                    MediaQuery.of(context).size.height * 0.25,
                    MediaQuery.of(context).size.width * 0.40,
                    Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          flex: 2,
                          child: Image.asset('assets/trouser.jpg',fit: BoxFit.fill,)),
                        // SizedBox(
                        //   width: 2,
                        // ),
                         Text(
                          'Mens trousers',
                          style: TextStyle(fontWeight: FontWeight.bold,color: Theme.of(context).accentColor),
                        )
                      ],
                    ),
                    context)
              ],
            ),
          ),
          
        ],
      ),
  );

}
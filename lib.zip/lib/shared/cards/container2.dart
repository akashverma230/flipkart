import 'package:flipkart/shared/cards/usercard.dart';
import 'package:flutter/material.dart';

Widget Container2(int a, int b, int c, BuildContext context) {
  return Container(
    width: MediaQuery.of(context).size.width,
    color: Color.fromARGB(255, a, b, c),
    margin: EdgeInsets.all(5),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        UserCard(
            MediaQuery.of(context).size.height * 0.18,
            MediaQuery.of(context).size.width * 0.30,
            Column(
              children: [
                Expanded(
                    flex: 2,
                    child: Image.asset(
                      'assets/8.jpg',
                      fit: BoxFit.fill,
                    )),
                Expanded(
                    flex: 1,
                    child: Text(
                      'Oneplus 8 series',
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          color: Theme.of(context).accentColor),
                    ))
              ],
            ),
            context),
        UserCard(
            MediaQuery.of(context).size.height * 0.18,
            MediaQuery.of(context).size.width * 0.30,
            Column(
              children: [
                Expanded(
                    flex: 2,
                    child: Image.asset('assets/speaker.jpg', fit: BoxFit.fill)),
                Expanded(
                    flex: 1,
                    child: Text(
                      'Upto 80% off',
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          color: Theme.of(context).accentColor),
                    ))
              ],
            ),
            context),
        UserCard(
            MediaQuery.of(context).size.height * 0.18,
            MediaQuery.of(context).size.width * 0.30,
            Column(
              children: [
                Expanded(
                    flex: 2,
                    child: Image.asset('assets/8.jpg', fit: BoxFit.fill)),
                Expanded(
                    flex: 1,
                    child: Text(
                      'just 499',
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          color: Theme.of(context).accentColor),
                    ))
              ],
            ),
            context),
      ],
    ),
  );
}

import 'package:flutter/material.dart';

import 'usercard.dart';

Widget UserContainer(int a,int b,int c,BuildContext context,String s){
  return Container(
    decoration: BoxDecoration(
      color: Color.fromARGB(
      255, a, b, c),

      borderRadius: BorderRadius.vertical(
        top: Radius.circular(5)
      )
    ),
        child: Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [Text(s,style: Theme.of(context).textTheme.titleLarge),
          CircleAvatar(child: Icon(Icons.arrow_right),radius: 15,)
          ]),
        ),
        SizedBox(height: MediaQuery.of(context).size.height*0.03,),
        Row(
          children: [
            Expanded(
              child: UserCard(
                  MediaQuery.of(context).size.height*0.30,
                  MediaQuery.of(context).size.width *0.20,
                  Column(
                    children: [
                      Image.asset('assets/smw.png'),
                      Text('Smart Watches',style: TextStyle(color: Theme.of(context).accentColor),),
                      Text('Under  299',style: TextStyle(color: Colors.green),)
                    ],
                  ),context
            ),
        ),
            Expanded(
              child: UserCard(
                  MediaQuery.of(context).size.height*0.30,
                  MediaQuery.of(context).size.width *0.20,
                  Column(
                    children: [
                      Image.asset('assets/smw.png'),
                      Text('Devices',style: TextStyle(color: Theme.of(context).accentColor)),
                      Text('Under  299',style: TextStyle(color: Colors.green),)
                    ],
                  ),context
            )
        )],
        ),
        Row(
          children: [
            Expanded(
              
              child: UserCard(
MediaQuery.of(context).size.height*0.30,
                  MediaQuery.of(context).size.width *0.20,
                  Column(
                    children: [
                      Image.asset('assets/smw.png'),
                      Text('Smart Watches',style: TextStyle(color: Theme.of(context).accentColor)),
                      Text('Under  299',style: TextStyle(color: Colors.green),)
                    ],
                  ),context
            ),),
            Expanded(
              
              child: UserCard(
                  MediaQuery.of(context).size.height*0.30,
                  MediaQuery.of(context).size.width *0.20,
Column(
                    children: [
                      Image.asset('assets/smw.png'),
                      Text('Devices',style: TextStyle(color: Theme.of(context).accentColor)),
                      Text('Under  299',style: TextStyle(color: Colors.green),)
                    ],
                  ),context
            )
        )],
        )
      ],
    ),
  );

}
import 'package:flutter/material.dart';

import 'language_enum.dart';

class Language extends StatefulWidget {
  const Language({Key? key}) : super(key: key);

  @override
  State<Language> createState() => _LanguageState();
}

languageTitleEnum? _languageTitleEnum = languageTitleEnum.English;

class _LanguageState extends State<Language> {
  String lang = "";
  var list = [
    "Hindi",
    "English",
    "Punjabi",
    "Assamese",
    " teglu",
    "Tamil",
    "Bengali",
    "Marathi",
    "kannada",
    "Odia",
    "Gujrati",
    "Malyalm",
  ];
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          backgroundColor: Colors.blue[900],
          title: Text("Choose Language"),
        ),
        body: Column(
          children: [
            Expanded(
              child: ListView.builder(
                  itemCount: 12,
                  itemBuilder: (context, i) {
                    return languageTile(context, i);
                  }),
            ),
            SizedBox(
              width: MediaQuery.of(context).size.width,
              child: Padding(
                padding: const EdgeInsets.only(left: 8, right: 8),
                child: MaterialButton(
                  onPressed: () {
                    Navigator.of(context).pushNamed("/login");
                  },
                  color: lang.length == 0 ? Colors.grey : Colors.orange,
                  child: Text(
                    "CONTINUE",
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget languageTile(BuildContext context, int index) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Colors.grey,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Radio(
              value: list[index],
              groupValue: lang,
              onChanged: (String? value) {
                setState(() {
                  lang = value!;
                });
              },
            ),
            Text(list[index]),
            Icon(Icons.access_alarm)
          ],
        ),
      ),
    );
  }
}

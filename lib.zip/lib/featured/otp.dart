import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

import 'login.dart';

class Otp extends StatefulWidget {
  const Otp({super.key});

  @override
  State<Otp> createState() => _OtpState();
}

class _OtpState extends State<Otp> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  var code = '';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
        leading: Icon(Icons.arrow_back),
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            SizedBox(height: MediaQuery.of(context).size.height*0.10,),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                decoration: BoxDecoration(border: Border.all(width: 2,color: Colors.blue,),borderRadius: BorderRadius.circular(10)),
                child: TextField(
                  decoration: InputDecoration(hintText:'Enter otp' ),
                  onChanged: (value) {
                    code = value;
                  },
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            InkWell(
              
              onTap: (){},
              child: Text('Entered Wrong Number?',style: TextStyle(fontWeight: FontWeight.bold,color: Colors.red),)),
              SizedBox(
              height: 10,
            ),
            ElevatedButton(
                onPressed: () async {
                  try {
                    PhoneAuthCredential credential = PhoneAuthProvider.credential(
                        verificationId: Login.verify, smsCode: code);
                    await _auth.signInWithCredential(credential);
                    Navigator.pushNamedAndRemoveUntil(
                        context, '/navbar', (route) => false);
                  } catch (e) {
                    SnackBar(
                      content: Text('Invalid Input'),
                    );
                  }
                },
                child: Text('Verify Otp')),
              SizedBox(height:MediaQuery.of(context).size.height*0.20 ,),
                Container(
                  height: MediaQuery.of(context).size.height*0.10,
                  child: Image.asset('assets/flipkart_icon.png'))
          ],
        ),
      ),
    );
  }
}

import 'package:firebase_core/firebase_core.dart';
import 'package:flipkart/featured/navbar.dart';
import 'package:flipkart/featured/otp.dart';
import 'package:flipkart/pages/notification.dart';
import 'package:flipkart/splashscreen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'featured/language.dart';
import 'featured/login.dart';
import 'pages/homepage.dart';
import 'shared/Themes/apptheme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MultiProvider(
    providers: [ChangeNotifierProvider(create: (_) => ThemeProvider())],
    child: MyApp(),
  ));
}

class MyApp extends StatelessWidget {
  Widget build(BuildContext context) {
    return MaterialApp(
      themeMode: context.watch<ThemeProvider>().getTheme
          ? ThemeMode.dark
          : ThemeMode.light,
      theme: Themes.light(),
      darkTheme: Themes.dark(),
      debugShowCheckedModeBanner: false,
      // themeMode: appState.isDark?ThemeMode.dark:ThemeMode.light,

      home: NavBar()
      // routes: {
      //   '/': (context) => SplashScreen(),
      //   "/languagePage": (context) => Language(),
      //   "/login": (context) => Login(),
      //   "/navbar": (context) => NavBar(),
      //   "/home": (context) => HomePage(),
      //   "/otp": (context) => Otp(),
      //   "/notification": (context) => Notify()
      // },
    );
  }
}

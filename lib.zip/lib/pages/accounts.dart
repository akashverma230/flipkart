import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class Accounts extends StatefulWidget {
  const Accounts({super.key});

  @override
  State<Accounts> createState() => _AccountsState();
}

class _AccountsState extends State<Accounts> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 0,
        title: Text(
          "Account",
          style: TextStyle(
            color: Theme.of(context).accentColor
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Row(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    "Login in to get exclusic offers",
                    style: TextStyle(
                      fontSize: 16,
                      color: Theme.of(context).accentColor
                    ),
                  ),
                ),
                Spacer(),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.of(context, rootNavigator: true)
                          .pushNamed("/login");
                    },
                    child: Text('Login In'),
                  ),
                ),
              ],
            ),
            Divider(
              height: 10,
              thickness: 8,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    "Account Settings",
                    style: TextStyle(
                      fontWeight: FontWeight.normal,
                      fontSize: 22,
                      color: Theme.of(context).accentColor,
                      
                    ),
                  ),
                ),
                InkWell(
                  onTap: () {
                    Navigator.of(context, rootNavigator: true)
                        .pushNamed("/languagePage");
                  },
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(Icons.access_alarm,color: Theme.of(context).accentColor),
                      ),
                      SizedBox(
                        height: 50,
                        width: 10,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "Select Language",
                          style: TextStyle(
                            fontSize: 15,
                            color: Theme.of(context).accentColor,
                            
                          ),
                        ),
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.43,
                      ),
                      Icon(
                        Icons.arrow_forward_ios,
                        size: 12,
                        color: Theme.of(context).accentColor
                      ),
                    ],
                  ),
                ),
                InkWell(
                  onTap: () {
                    Navigator.of(context, rootNavigator: true).pushNamed(
                      "/notification",
                    );
                  },
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(Icons.notifications,color: Theme.of(context).accentColor),
                      ),
                      SizedBox(
                        height: 50,
                        width: 10,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "Notification Settings",
                          style: TextStyle(
                            fontSize: 15,
                            color: Theme.of(context).accentColor,
                            
                          ),
                        ),
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.36,
                      ),
                      Icon(
                        Icons.arrow_forward_ios,
                        size: 12,
                        color: Theme.of(context).accentColor
                      ),
                    ],
                  ),
                ),
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.help_center,color: Theme.of(context).accentColor),
                    ),
                    SizedBox(
                      height: 50,
                      width: 10,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        "Help Center",
                        style: TextStyle(
                          fontSize: 15,
                          color: Theme.of(context).accentColor,
                          
                        ),
                      ),
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.52,
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 12,
                      color: Theme.of(context).accentColor
                    ),
                  ],
                ),
              ],
            ),
            Divider(
              height: 10,
              thickness: 8,
            ),
            Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      "Earn With Flipkart",
                      style: TextStyle(
                        fontWeight: FontWeight.normal,
                        fontSize: 22,
                        color: Theme.of(context).accentColor,
                        
                      ),
                    ),
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(Icons.sell_rounded,color: Theme.of(context).accentColor),
                      ),
                      SizedBox(
                        height: 50,
                        width: 10,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "Sell on Flipkart",
                          style: TextStyle(
                            fontSize: 15,
                            color: Theme.of(context).accentColor
                          ),
                        ),
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.47,
                      ),
                      Icon(
                        Icons.arrow_forward_ios,
                        size: 12,
                        color: Theme.of(context).accentColor
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Divider(
              height: 10,
              thickness: 8,
            ),
            Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      "Feedback & Information",
                      style: TextStyle(
                        fontWeight: FontWeight.normal,
                        fontSize: 22,
                        color: Theme.of(context).accentColor
                      ),
                    ),
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(Icons.policy_sharp,color: Theme.of(context).accentColor),
                      ),
                      SizedBox(
                        height: 50,
                        width: 10,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "Terms, Policies and Licenses",
                          style: TextStyle(
                            fontSize: 15,
                            color: Theme.of(context).accentColor
                          ),
                        ),
                      ),
                      SizedBox(width: MediaQuery.of(context).size.width * 0.21),
                      Icon(
                        Icons.arrow_forward_ios,
                        size: 12,
                        color: Theme.of(context).accentColor
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Row(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Icon(
                    Icons.browse_gallery_sharp,
                    color: Theme.of(context).accentColor
                  ),
                ),
                SizedBox(
                  height: 50,
                  width: 10,
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    "Browse FAQs",
                    style: TextStyle(
                      fontSize: 15,
                      color: Theme.of(context).accentColor
                    ),
                  ),
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.50,
                ),
                Icon(
                  Icons.arrow_forward_ios,
                  size: 12,
                  color: Theme.of(context).accentColor
                ),
              ],
            ),
            Container(),
            Divider(
              height: 100,
              thickness: 90,
            ),
          ],
        ),
      ),
    );
  }
}

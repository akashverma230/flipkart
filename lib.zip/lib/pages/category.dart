import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

import '../shared/cards/avatar.dart';
import '../shared/cards/usercard.dart';

class Category extends StatefulWidget {
  const Category({super.key});

  @override
  State<Category> createState() => _CategoryState();
}

class _CategoryState extends State<Category> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('All Categories'),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Icon(Icons.search),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Icon(Icons.mic),
          )
        ],
      ),
      body: ListView(
        children: [
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Avatar('Supercoin', Image.asset('assets/supercoin.jpg'), context),
              Avatar('coupons', Image.asset('assets/coupons.png'), context),
              Avatar('Credit', Image.asset('assets/credit.jpg'), context),
              Avatar('Group Buy', Image.asset('assets/grp.jpg'), context),
              //Avatar('Whats New',Image.asset('assets/new.jpg')),
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              //Avatar('Supercoin',Image.asset('assets/supercoin.jpg')),
              Avatar('coupons', Image.asset('assets/coupons.png'), context),
              Avatar('Credit', Image.asset('assets/credit.jpg'), context),
              Avatar('Group Buy', Image.asset('assets/grp.jpg'), context),
              Avatar('Whats New', Image.asset('assets/new.jpg'), context)
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Avatar('Supercoin', Image.asset('assets/supercoin.jpg'), context),
              Avatar('coupons', Image.asset('assets/coupons.png'), context),
              Avatar('Group Buy', Image.asset('assets/grp.jpg'), context),
              Avatar('Whats New', Image.asset('assets/new.jpg'), context)
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Avatar('Supercoin', Image.asset('assets/supercoin.jpg'), context),
              Avatar('coupons', Image.asset('assets/coupons.png'), context),
              Avatar('Credit', Image.asset('assets/credit.jpg'), context),
              Avatar('Whats New', Image.asset('assets/new.jpg'), context)
            ],
          ),
          Row(
            //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Avatar('Supercoin', Image.asset('assets/supercoin.jpg'), context),
              Avatar('coupons', Image.asset('assets/coupons.png'), context),
              Avatar('Whats New', Image.asset('assets/new.jpg'), context)
            ],
          ),
          Row(
            // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Avatar('Supercoin', Image.asset('assets/supercoin.jpg'), context),
              Avatar('Whats New', Image.asset('assets/new.jpg'), context)
            ],
          ),
          Divider(
            height: 10,
          ),
          SizedBox(
            height: 15,
          ),
          Container(
            child: Text(
              "Trending Stores",
              style: TextStyle(color: Colors.black, fontSize: 20),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Divider(
            height: 10,
          ),
          Row(
            children: [
              UserCard(
                  MediaQuery.of(context).size.height * 0.25,
                  MediaQuery.of(context).size.width * 0.50,
                  Stack(
                    children: [
                      Expanded(
                        child: Image.asset(
                          'assets/well.png',
                          height: 210,
                          fit: BoxFit.fill,
                        ),
                      ),
                      Column(
                        children: [
                          Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  'Wellness Store',
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                              Icon(
                                Icons.arrow_forward_ios,
                                size: 10,
                              ),
                            ],
                          ),
                          Text(
                            'For All Health needs',
                            textAlign: TextAlign.start,
                            style: TextStyle(
                              color: Colors.black54,
                            ),
                          )
                        ],
                      ),
                    ],
                  ),
                  context),
              UserCard(
                  MediaQuery.of(context).size.height * 0.25,
                  MediaQuery.of(context).size.width * 0.50,
                  Stack(
                    children: [
                      Image.asset(
                        'assets/well.png',
                        height: 210,
                        fit: BoxFit.fill,
                      ),
                      Column(
                        children: [
                          Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  'Wellness Store',
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                              Icon(
                                Icons.arrow_forward_ios,
                                size: 10,
                              ),
                            ],
                          ),
                          Text(
                            'For All Health needs',
                            textAlign: TextAlign.start,
                            style: TextStyle(
                              color: Colors.black54,
                            ),
                          )
                        ],
                      ),
                    ],
                  ),
                  context)
            ],
          ),
          Divider(
            height: 15,
          ),
          Row(
            children: [
              UserCard(
                  MediaQuery.of(context).size.height * 0.25,
                  MediaQuery.of(context).size.width * 0.50,
                  Stack(
                    children: [
                      Image.asset(
                        'assets/well.png',
                        height: 210,
                        fit: BoxFit.fill,
                      ),
                      Column(
                        children: [
                          Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  'Wellness Store',
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                              Icon(
                                Icons.arrow_forward_ios,
                                size: 10,
                              ),
                            ],
                          ),
                          Text(
                            'For All Health needs',
                            textAlign: TextAlign.start,
                            style: TextStyle(
                              color: Colors.black54,
                            ),
                          )
                        ],
                      ),
                    ],
                  ),
                  context),
              UserCard(
                  MediaQuery.of(context).size.height * 0.25,
                  MediaQuery.of(context).size.width * 0.50,
                  Stack(
                    children: [
                      Image.asset(
                        'assets/well.png',
                        height: 210,
                        fit: BoxFit.fill,
                      ),
                      Column(
                        children: [
                          Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  'Wellness Store',
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                              Icon(
                                Icons.arrow_forward_ios,
                                size: 10,
                              ),
                            ],
                          ),
                          Text(
                            'For All Health needs',
                            textAlign: TextAlign.start,
                            style: TextStyle(
                              color: Colors.black54,
                            ),
                          )
                        ],
                      ),
                    ],
                  ),
                  context)
            ],
          ),
          Divider(
            height: 15,
          ),
          Row(
            children: [
              UserCard(
                  MediaQuery.of(context).size.height * 0.25,
                  MediaQuery.of(context).size.width * 0.50,
                  Stack(
                    children: [
                      Image.asset(
                        'assets/well.png',
                        height: 210,
                        fit: BoxFit.fill,
                      ),
                      Column(
                        children: [
                          Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  'Wellness Store',
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                              Icon(
                                Icons.arrow_forward_ios,
                                size: 10,
                              ),
                            ],
                          ),
                          Text(
                            'For All Health needs',
                            textAlign: TextAlign.start,
                            style: TextStyle(
                              color: Colors.black54,
                            ),
                          )
                        ],
                      ),
                    ],
                  ),
                  context),
              UserCard(
                  MediaQuery.of(context).size.height * 0.25,
                  MediaQuery.of(context).size.width * 0.50,
                  Stack(
                    children: [
                      Image.asset(
                        'assets/well.png',
                        height: 210,
                        fit: BoxFit.fill,
                      ),
                      Column(
                        children: [
                          Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  'Wellness Store',
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                              Icon(
                                Icons.arrow_forward_ios,
                                size: 10,
                              ),
                            ],
                          ),
                          Text(
                            'For All Health needs',
                            textAlign: TextAlign.start,
                            style: TextStyle(
                              color: Colors.black54,
                            ),
                          )
                        ],
                      ),
                    ],
                  ),
                  context)
            ],
          ),
        ],
      ),
    );
  }
}
